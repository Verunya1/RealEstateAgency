package com.example.realestateagency;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealEstateAgencyApplicationTests {

    @Test
    void contextLoads() {
    }

}
